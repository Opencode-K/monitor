<template>
  <a-card title="报警日志" style="margin-top:24px; max-height:300px; overflow-y:auto">
    <a-list
      :data-source="alarms"
      bordered
      :locale="{ emptyText: '暂无报警' }"
    >
      <template #renderItem="{ item }">
        <a-list-item :style="{ background: item.ack ? '#f0f0f0' : '#fff' }">
          <a-space direction="vertical" style="width:100%">
            <a-space>
              <a-tag :color="item.ack ? 'default' : 'error'">{{ item.task }}</a-tag>
              <span>{{ item.camera }}</span>
              <span>{{ formatTime(item.time) }}</span>
            </a-space>
            <a-space>
              <span>{{ item.label }} ({{ (item.conf*100).toFixed(1) }}%)</span>
              <a-button
                v-if="!item.ack"
                type="link"
                size="small"
                @click="ack(item.id)"
              >确认</a-button>
            </a-space>
          </a-space>
        </a-list-item>
      </template>
    </a-list>
  </a-card>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import axios from '@/utils/axios'

const props = defineProps({
  /** 对应后端写入时的 task 字段 */
  task: { type: String, default: '' }
})
const alarms = ref([])
const filteredAlarms = ref([])

// ISO 时间转本地可读格式
function formatTime(iso) {
  const dt = new Date(iso)
  return dt.toLocaleString()
}

async function fetchAlarms() {
  try {

    const res = await axios.get('/detection/alarms')
    alarms.value = props.task
      ? res.data.filter(a => a.task === props.task)
      : res.data
  } catch (e) {
    console.error('拉取报警日志失败', e)
  }
}
// 确认报警
async function ack(id) {
  try {
    await axios.put(`/alarms/${id}/ack`)
    fetchAlarms()
  } catch (e) {
    console.error('确认报警失败', e)
  }
}

function applyFilter() {
  filteredAlarms.value = alarms.value.filter(a => a.task === props.task)
}
onMounted(() => {
  fetchAlarms()
  setInterval(fetchAlarms, 2000)
})

watch(alarms, applyFilter)
</script>

<style scoped>
/* 根据需要加一点内边距 */
.a-list-item {
  padding: 8px 16px;
}
</style>
