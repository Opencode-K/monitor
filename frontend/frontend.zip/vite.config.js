// frontend/vite.config.js
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src')
    }
  },
  optimizeDeps: {
    include: ['ant-design-vue']
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://10.156.232.9:5000',
        changeOrigin: true,
        secure: false
      },
      '/stream': {
        target: 'http://10.156.232.9:5000',
        changeOrigin: true,
        secure: false
      }
    }
  }
})
